import java.sql.*;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.github.kevinsawicki.http.HttpRequest;

public class Main2014302580369 {  
    private static Connection conn; 
	static String sql;
    public static void main(String[] args) throws SQLException {  
        try {  
            Class.forName("com.mysql.jdbc.Driver").newInstance();  
            System.out.println("成功创建数据表");  
        } catch (InstantiationException e) {    
            e.printStackTrace();  
        } catch (IllegalAccessException e) {  
            e.printStackTrace();  
        } catch (ClassNotFoundException e) {            
            e.printStackTrace();  
        }  
          
        try {  
            conn=DriverManager.getConnection("jdbc:mysql://localhost/beyondyushen", "root", "z"); 
        } catch (SQLException e) {    
            e.printStackTrace();  
        }  
        Long singlestartTime;
        Long singleendTime;
        singlestartTime = System.currentTimeMillis();
        getnews();
        singleendTime = System.currentTimeMillis();
        long multiStartTime=System.currentTimeMillis();		
		Thread t1=new Thread();
		Thread t2=new Thread();		
		getnews();
		t1.start();
		t2.start();	
		long multiEndTime=System.currentTimeMillis();
		System.out.println("单线程耗时:"+(singleendTime-singlestartTime)+"ms");
		System.out.println("多线程耗时："+(multiEndTime-multiStartTime)+"ms");
    }  
    public static  void getnews() throws SQLException{ 
    	String url ="http://www.wpi.edu/academics/cs/research-interests.html";
		   String gname = "news"+".html"; 
		 	   HttpRequest response = HttpRequest.get(url);
		    			   response.receive(new File(gname));
		    	System.out.printf("get\n");
				try
				{
				File file=new File("news.html");
				Document doc=Jsoup.parse(file,"UTF-8");			
				Elements ele=doc.getElementsByClass("half");
				Elements links=ele.select("a");
				String name;
				String research;
				for(Element link:links) {
					String linkHref=link.attr("href");					
					HttpRequest response1=HttpRequest.get(linkHref);
					System.out.println(response1.toString());
					String fn="Teacher.html";
					response1.receive(new File(fn));				
					//name
					File file1=new File("teacher.html");
					Document doc1=Jsoup.parse(file1,"UTF-8",linkHref);
					Elements conment=doc1.getElementsByTag("h2");
					name=conment.text();
					if(name.length() > 100){
						 name = name.substring(0, 99);
					 }
					//research
					Elements ele2=doc1.getElementsByClass("col");
					research=ele2.text().replaceAll(" ","\r\n");
					Statement stmt = conn.createStatement();
					if(research.length()> 20000){
						research =research.substring(0, 19999);
					 }
					
                     sql = "insert into beyond(name,research) values( '"+name +"', '"+research+"')";
		                stmt.executeUpdate(sql);
				}
				}
				catch(IOException e) {
					e.printStackTrace();
				}
	}
    	
    }
  
 